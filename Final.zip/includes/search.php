<?php

include 'includes/art-config.inc.php';

try {
    
    // connect and retrieve data for filters    
    $artistDB = new ArtistDB($pdo);
    $artists = $artistDB->getAll();   
    
    $galleryDB = new GalleryDB($pdo);
    $galleries = $galleryDB->getAll(); 
    
    $shapeDB = new ShapeDB($pdo);
    $shapes = $shapeDB->getAll();    
    
    
    // now retrieve artists ... either all or a subset
    $paintDB = new artistDB($pdo);
    
    // filter by artist?
    if (isset($_GET['artist']) && ! empty($_GET['artist'])) {
        $artists = $paintDB->findByArtist($_GET['artist']);
        
        $artist = $artistDB->findById($_GET['artist']);
        $filter = 'Artist = ' . makeArtistName($artist['FirstName'],$artist['LastName']) ;
    }
    
    // filter by museum?
    if (isset($_GET['museum']) && ! empty($_GET['museum'])) {
        $artists = $paintDB->findByGallery($_GET['museum']);
        
        $museum = $galleryDB->findById($_GET['museum']);
        $filter = 'Museum = ' . utf8_encode($museum['GalleryName']);
    }    
    
    // filter by shape?
    if (isset($_GET['shape']) && ! empty($_GET['shape'])) {
        $artists = $paintDB->findByShape($_GET['shape']);
        
        $shape = $shapeDB->findById($_GET['shape']);
        $filter = 'Shape = ' . $shape['ShapeName'];
    }     
                                            
    if (! isset($artists) || $artists->rowCount() == 0) {
        $artists = $paintDB->getAll();
        $filter = "All artists [Top 20]";
    }
    
        
}
catch (PDOException $e) {
   die( $e->getMessage() );
}

function outputOptions($data, $valueField, $dataField) {
  while ($single = $data->fetch()) { 
    echo '<option value=' . $single[$valueField] . '>';
    echo utf8_encode($single[$dataField]);
    echo '</option>'; 
  }       
}

function makeArtistName($first, $last) {
    return utf8_encode($first . ' ' . $last);
}

?>
<!DOCTYPE html>
<html lang=en>
<head>
    <meta charset=utf-8>
    <link href='http://fonts.googleapis.com/css?family=Merriweather' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script src="css/semantic.js"></script>
        <script src="js/misc.js"></script>
    
    <link href="css/semantic.css" rel="stylesheet" >
    <link href="css/icon.css" rel="stylesheet" >
    <link href="css/styles.css" rel="stylesheet">
    
</head>
<body >
    
<?php include 'includes/art-header.inc.php'; ?>
    
<main class="ui segment doubling stackable grid container">
 <?php
  
  if(isset($_POST['submit'])){
    if(isset($_GET['go'])){
      if(preg_match("^/[A-Za-z]+/", $_POST['name'])){
        $name=$_POST['name'];
        $sql="SELECT Artists.FirstName, Artists.LastName, Paintings.ArtistID, Paintings.Title, Paintings.ImageFileName FROM Paintings INNER JOIN Artists ON Paintings.ArtistID=Artists.ArtistID WHERE Paintings.Title LIKE '%" . $name . "%";
        $result=mysql_query($sql);
        while($row=mysql_fetch_array($result)){
          $FirstName=$row['FirstName'];
          $LastName=$row['LastName'];
          $Title=$row['Title'];
          $Image=$row['ImageFielName'];
          
          echo "<ul>\n";
          echo "<li>" . "<a class='ui small image' href='single-painting.php?id=<?php echo $work['PaintingID']; ?>'><img src='images/art/works/square-medium/<?php echo $work['ImageFileName']; ?>.jpg'></a>" . "<a class='header' href='single-painting.php?id=<?php echo $work['PaintingID']; ?>$Title</a>" .$FirstName . " " . $LastName .  "</a></li>\n";
      }
    } else {
    echo  "<p>Please enter a search query</p>";
  }
  
  ?>
    
</main>
    

    
  <footer class="ui black inverted segment">
      <div class="ui container">footer for later</div>
  </footer>
</body>
</html>