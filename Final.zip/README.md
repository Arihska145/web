
 To configure database connection, edit includes/art-config.inc.php