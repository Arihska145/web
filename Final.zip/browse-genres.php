<?php

include 'includes/art-config.inc.php';

?>

<?php include 'includes/art-header.inc.php'; ?>